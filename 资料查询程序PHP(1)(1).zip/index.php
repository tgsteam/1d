<?php
include("./include/common.php");
?>
<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <title><?php echo $sitename;?></title>
	<meta name="keywords" content="<?php echo $keywords;?>"/>
	<meta name="description" content="<?php echo $description;?>"/>
    <link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet">
    <script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
    <script src="//cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--[if lt IE 9]>
      <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	body{
		margin: 0 auto;
		text-align: center;
	}
	.container {
	  max-width: 580px;
	  padding: 15px;
	  margin: 0 auto;
	}
	</style>
</head>
<body background="./images/bj/bj-5.jpg">
<div class="container">    <div class="header">
        <ul class="nav nav-pills pull-right" role="tablist">
          <li role="presentation" class="active"><a href="./">查询</a></li>
          <li role="presentation"><a href="http://wpa.qq.com/msgrd?v=3&uin=1455112844&site=qq&menu=yes" target="_blank">联系站长</a></li>
        </ul>
        <h3 class="text-muted" align="left"><font color="#8968CD">某宅密码查询系统</font></h3>
     </div><hr>
 <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">公告栏</h3></div>
		<ul class="list-group">
		
		  <script>   //滚动链接代码
var marqueeContent=new Array();   //滚动新闻

marqueeContent[0]='<font color="#FF3333">小广告: </font><a href="http://www.zy40.cn">点击加入程序更新</a><br>';
marqueeContent[1]='<font color="#FF3333">小广告: </font><a href="http://h.zy40.cn" target=_blank class="f12red">某宅大帅逼</a><br>';
marqueeContent[2]='<font color="#CC0000">公告: </font><a href="#" target=_blank class="f12red">历史资料每天都会更新欢迎大家查询</a><br>';
marqueeContent[3]='<font color="#CC0000">公告: </font><a href="http://www.zy40.cn" target=_blank class="f12red">某宅大帅逼</a><br>';
var marqueeInterval=new Array();  //定义一些常用而且要经常用到的变量
var marqueeId=0;
var marqueeDelay=5000;
var marqueeHeight=20;
//接下来的是定义一些要使用到的函数
function initMarquee() {
    var str=marqueeContent[0];
    document.write('<div id=marqueeBox style="overflow:hidden;height:'+marqueeHeight+'px" onmouseover="clearInterval(marqueeInterval[0])" onmouseout="marqueeInterval[0]=setInterval(\'startMarquee()\',marqueeDelay)"><div>'+str+'</div></div>');
    marqueeId++;
    marqueeInterval[0]=setInterval("startMarquee()",marqueeDelay);
    }
function startMarquee() {
    var str=marqueeContent[marqueeId];
        marqueeId++;
    if(marqueeId>=marqueeContent.length) marqueeId=0;
    if(marqueeBox.childNodes.length==1) {
        var nextLine=document.createElement('DIV');
        nextLine.innerHTML=str;
        marqueeBox.appendChild(nextLine);
        }
    else {
        marqueeBox.childNodes[0].innerHTML=str;
        marqueeBox.appendChild(marqueeBox.childNodes[0]);
        marqueeBox.scrollTop=0;
        }
    clearInterval(marqueeInterval[1]);
    marqueeInterval[1]=setInterval("scrollMarquee()",20);
    }
function scrollMarquee() {
    marqueeBox.scrollTop++;
    if(marqueeBox.scrollTop%marqueeHeight==(marqueeHeight-1)){
        clearInterval(marqueeInterval[1]);
        }
    }
initMarquee();
</script> 
		
		<li class="list-group-item">历史密码查询</li>
		<li class="list-group-item">网络鱼龙混杂交易请谨慎避免金钱损失 </li>
		<li class="list-group-item">当前系统录入资料QQ累计70万+ </li>
</p><p></p><b><a class="btn btn-block btn-danger" data-toggle="collapse" data-parent="#accordion2" href="#faq1" aria-expanded="false">我想删除我的资料要怎么做？</a></b><div id="faq1" class="accordion-body collapse" style="height: 0px;" aria-expanded="false"><h5>申请删除请把有效资料整理好，可以通过快速QQ联系审核人员，所有删除申请，我都会及时处理的<p></p></h5></div><p></p>
</marquee></a>
<p class="bg-primary" style="background-color:#FF9900;padding: 3px;"><img border="0" width="32" src="1.gif" />被他人恶意举报，QQ被恶意收录，请联系解除<a href="http://wpa.qq.com/msgrd?v=3&uin=1455112844&site=qq&menu=yes" target="_blank" class="btn btn-success btn-xs">联系站长</a>
<ul class="list-group">
  <li class="list-group-item"><span class="glyphicon glyphicon-time"></span> <b>现在时间：</b> <?=$date?></li>
		</ul>
      </div>
	 <h3 class="form-signin-heading">输入自己的QQ进行查询</h3><br/>目前只支持QQ。
	 <form action="" class="form-sign" method="post">
	 <input type="text" class="form-control" name="qq" placeholder="请输入查询骗子联系方式点击下面查询" value=""><br>
	 <input type="submit" class="btn btn-primary btn-block" value="点击查询"><br/>
	 <p style="text-align:left">
<?php
if($qq=$_POST['qq']) {
	$qq=$_POST['qq'];
	$row=$DB->get_row("SELECT * FROM black_list WHERE qq='$qq' limit 1");
	echo '<label>查询信息：'.$qq.'</label><br>';
	if($row) {
		echo '
		<label>泄露等级：</label>
		<font color="blue">'.$row['level'].'级</font><br>
		<label>入库时间：</label>
		<font color="blue">'.$row['date'].'</font><br>
		<label>历史密码：</label>
		<font color="blue">'.$row['note'].'</font><br>
		<label><font color="red">请停止任何交易！</font></label>';
?>
<br><label>分享结果：</label>
<input type="text" style="width:350px;" class="shareUrl" onClick="this.select()" value="">
<?php
	}else{
		echo '<label><font color="green">该用户信息尚未被录入！但是我们不能保证您资料绝对安全，某宅提醒大家：网络交易风险大，大金额交易请谨慎。</font></label>';
	}
}
$DB->close();
?>
	 </p><hr><div class="container-fluid">
  <a href="http://wpa.qq.com/msgrd?v=3&uin=1455112844&site=qq&menu=yes" target="_blank" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-erase"></span> 举报</a>
  <a href="./admin/" target="_blank" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-user"></span> 管理</a>
</div>
<p style="text-align:center">
<br><label>友情链接：</label><a href="http://www.zy40.cn"target="_blank">某宅内部查询</a><label>|</label> <a href="http://h.zy40.cn" target="_blank">某宅工作室</a><label>|</label> <a href="http://www.zy40.cn" target="_blank">广告请联系我</a>
<br>Powered by 某宅工作室 All rights reserved<br>
Copyright&copy;2016–2021某宅工作室</a>
</div>
</body>
</html>
